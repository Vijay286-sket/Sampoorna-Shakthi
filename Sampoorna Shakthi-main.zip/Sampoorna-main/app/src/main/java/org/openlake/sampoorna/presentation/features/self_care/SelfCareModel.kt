package org.openlake.sampoorna.presentation.features.self_care

data class SelfCareModel(
    var icons: Int? = 0,
    var name: String? = null
)